import m1 from '../images/movies/1.png';
 const moviesList = [
  {
    id:'1',
    nameRU: '«Роллинг Стоунз» в изгнании',
    duration: 107,
    link: m1,
    trailerLink: 'https://www.youtube.com/watch?v=UXcqcdYABFw'
  },
  {
    id:'2',
    nameRU: '«Роллинг Стоунз» в изгнании',
    duration: 84,
    link: 'https://api.nomoreparties.co/uploads/thumbnail_stones_in_exile_b2f1b8f4b7.jpeg',
    trailerLink: 'https://www.youtube.com/watch?v=UXcqcdYABFw'
  },
  {
    id:'3',
    nameRU: 'All Tomorrow\'s Parties',
    duration: 82,
    link: 'https://api.nomoreparties.co/uploads/thumbnail_all_tommoros_parties_33a125248d.jpeg',
    trailerLink: 'https://www.youtube.com/watch?v=UXcqcdYABFw'
  },
  {
    id:'4',
    nameRU: 'Без обратного пути',
    duration: 75,
    link: 'https://api.nomoreparties.co/uploads/thumbnail_blur_a43fcf463d.jpeg',
    trailerLink: 'https://www.youtube.com/watch?v=UXcqcdYABFw'
  },
  {
    id:'5',
    nameRU: 'Bassweight',
    duration: 61,
    link: 'https://api.nomoreparties.co/uploads/thumbnail_zagruzhennoe_113f557116.jpeg',
    trailerLink: 'https://www.youtube.com/watch?v=UXcqcdYABFw'
  }/*,
  {
    id:'6',
    nameRU: 'Taqwacore: The Birth of Punk Islam',
    duration: 80,
    link: 'https://api.nomoreparties.co/uploads/thumbnail_taqwacore2_2f487d2e74.jpeg',
    trailerLink: 'https://www.youtube.com/watch?v=UXcqcdYABFw'
  },
  {
    id:'7',
    nameRU: '«Роллинг Стоунз» в изгнании',
    duration: 107,
    link: m1,
    trailerLink: 'https://www.youtube.com/watch?v=UXcqcdYABFw'
  },
  {
    id:'8',
    nameRU: '«Роллинг Стоунз» в изгнании',
    duration: 58,
    link: 'https://api.nomoreparties.co/uploads/thumbnail_stones_in_exile_b2f1b8f4b7.jpeg',
    trailerLink: 'https://www.youtube.com/watch?v=UXcqcdYABFw'
  },
  {
    id:'9',
    nameRU: 'All Tomorrow\'s Parties',
    duration: 82,
    link: 'https://api.nomoreparties.co/uploads/thumbnail_all_tommoros_parties_33a125248d.jpeg',
    trailerLink: 'https://www.youtube.com/watch?v=UXcqcdYABFw'
  },
  {
    id:'10',
    nameRU: 'Без обратного пути',
    duration: 135,
    link: 'https://api.nomoreparties.co/uploads/thumbnail_blur_a43fcf463d.jpeg',
    trailerLink: 'https://www.youtube.com/watch?v=UXcqcdYABFw'
  },
  {
    id:'11',
    nameRU: 'Bassweight',
    duration: 61,
    link: 'https://api.nomoreparties.co/uploads/thumbnail_zagruzhennoe_113f557116.jpeg',
    trailerLink: 'https://www.youtube.com/watch?v=UXcqcdYABFw'
  },
  {
    id:'12',
    nameRU: 'Taqwacore: The Birth of Punk Islam',
    duration: 80,
    link: 'https://api.nomoreparties.co/uploads/thumbnail_taqwacore2_2f487d2e74.jpeg',
    trailerLink: 'https://www.youtube.com/watch?v=UXcqcdYABFw'
  }*/
]

export default moviesList;