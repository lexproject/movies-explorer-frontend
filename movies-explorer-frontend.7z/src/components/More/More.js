import './More.css';

function More(props) {
    return (
        <div className='more'>
            <button type='button' className='interactiv-element more__button'>Ещё</button>
        </div>
    );
}

export default More;