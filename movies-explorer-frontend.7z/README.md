* Frontend Movies Explorer

Вёрстка для Frontend проекта Movies Explorerю

* Сcылка на скачивание макета проекта для Figma
https://disk.yandex.ru/d/tJQHLRlORMxHrA
